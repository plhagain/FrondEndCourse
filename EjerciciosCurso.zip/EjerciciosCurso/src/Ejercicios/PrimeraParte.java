package Ejercicios;

public class PrimeraParte {


    public static void main(String[] args) {
        int ResultadoSuma = 0 ;
        ResultadoSuma = Sumar( 10, 20, 30 );
        System.out.println(ResultadoSuma);
        //......
       // Coche miCoche = new Coche();
        Coche miCoche = new Coche();

        miCoche.SumarPuertas();
        System.out.println(miCoche.numPuertas);

    }
    public static  int Sumar(int a, int b, int c){
        return a + b + c;
        // la función Sumar devuelve un Entero

    }
     static class Coche{
        public int numPuertas = 1;
        public void  SumarPuertas(){
            numPuertas++;
        }
        // ver porque debo declarar Static la clase para que me pueda crear una Instancia

    }


}
